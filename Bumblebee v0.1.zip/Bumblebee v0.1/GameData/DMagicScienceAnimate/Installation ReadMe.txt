Version 0.21
	KSP V 1.4-1.6

Installation:

Place the GameData folder in the main KSP folder.

Use the reference.cfg (available on the GitHub repo: https://github.com/DMagic1/DMModuleScienceAnimateGeneric/blob/master/reference.cfg) file to check the fields available, their function and their default values. The values shown are those for my magnetometer.

Add the module DMModuleScienceAnimateGeneric to your part.cfg file and configure as desired.

